package fs

// Version of rclone
var Version = "v1.35-DEV"
