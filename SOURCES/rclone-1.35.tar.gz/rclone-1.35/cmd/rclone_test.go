// Tests for rclone
package cmd

import (
	"testing"
)

func TestFIXME(t *testing.T) {
	// FIXME test something!
}
