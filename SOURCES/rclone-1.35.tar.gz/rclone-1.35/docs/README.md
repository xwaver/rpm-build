Docs
====

See the content directory for the docs in markdown format.

Use [hugo](https://github.com/spf13/hugo) to build the website.
