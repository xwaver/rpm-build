---
title: "Contact"
description: "Contact the rclone project"
date: "2014-04-26"
---

# Contact the rclone project #

## Forum ##

Forum for general discussions and questions:

  * https://forum.rclone.org

## Gitub project ##

The project website is at:

  * https://github.com/ncw/rclone

There you can file bug reports, ask for help or contribute pull
requests.

## Google+ ##

Rclone has a Google+ page which announcements are posted to

  * <a href="https://google.com/+RcloneOrg" rel="publisher">Google+ page for general comments</a>

## Twitter ##

You can also follow me on twitter for rclone announcments

  * [@njcw](https://twitter.com/njcw)

## Email ##

Or if all else fails or you want to ask something private or
confidential email [Nick Craig-Wood](mailto:nick@craig-wood.com)
