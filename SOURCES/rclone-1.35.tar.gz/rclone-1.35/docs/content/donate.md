---
title: "Flowers for My Wife"
description: "Flowers for My Wife."
type: page
date: "2015-09-06"
---

Flowers for My Wife
===================

Rclone is a pure open source for love-not-money project.  However I've
had requests for a donation page and coding it does take me away from
something else I love - my wonderful wife.

So if you would like to send a donation, I will use it to buy flowers
for her which will make her very happy.

<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="XQMMNUD5ZY49J">
<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>

If you would prefer to express your gratitude by promoting the
project, or helping with it, I'd be over the moon with that too!

Thanks

Nick