#pragma once

#ifdef _MSC_VER
#pragma warning(push, 0)
#endif

#include <QtDebug>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>

#ifdef Q_OS_WIN32
#include <QtWinExtras>
#endif

#ifdef Q_OS_OSX
#include <QtMacExtras>
#endif

#ifdef _MSC_VER
#pragma warning pop
#endif
