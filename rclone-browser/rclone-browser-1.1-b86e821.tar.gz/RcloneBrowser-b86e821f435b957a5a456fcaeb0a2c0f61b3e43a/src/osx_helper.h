#pragma once

#include "pch.h"

QIcon osxGetIcon(const QString& extension);
void osxHideDockIcon();
void osxShowDockIcon();
